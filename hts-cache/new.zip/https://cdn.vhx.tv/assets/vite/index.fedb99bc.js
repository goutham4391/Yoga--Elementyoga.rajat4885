import{r as o,a as e}from"./index.61149844.js";import{a as s}from"./index.9dc763b0.js";function d(r,a){o(2,arguments);var t=e(a);return s(r,t*12)}export{d as a};
//# sourceMappingURL=index.fedb99bc.js.map
