import{i as e}from"./isObject.c70885d8.js";import{i as o,e as a,s as t,p as n}from"./index.cae3477b.js";const c="UA-19540423-6",s=()=>window.VHX&&window.VHX.data?Boolean(window.VHX.data.should_set_cookies):!1,w=()=>{s()&&o(c)},d=i=>{s()&&e(i)&&a(i)},m=i=>{s()&&t(i)},p=(i=window.location.pathname)=>{s()&&n(i)};export{d as f,w as i,p,m as s};
//# sourceMappingURL=insights.063615ae.js.map
