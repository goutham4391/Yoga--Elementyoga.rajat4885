const e='"Helvetica Neue", "Helvetica", "Arial", sans-serif',t="5px",n="10px",c="20px",o="40px",r="80px",i="160px",l="5rem",u="#1a2e3b",d="#121212",f="#000",m="#3a5161",x="#8699a6",g="#496073",p="#b3bfc8",b="#e3e8e9",k="#7c93a6",B="#eef1f2",h="#f6f7f8",y="#fff",D="#515151",P="#657987",G="#666666",O="#23313b",H="#db2e2e",S="#ffeded",C="#ff4d4d",$="#ffb21e",v="#00adef",A="#e5f7fd",F="#111c25",U="#392d86",V="#0088cc",q="#36C5FC",z="#7FC400",I="#d93636";const a=s=>`${s/16}rem`,R=s=>`${8*s/16}rem`;const W=s=>`${5*s/16}rem`,w="cubic-bezier(0.25, 0.46, 0.45, 0.94)",Q="cubic-bezier(0.645, 0.045, 0.355, 1)",T=`
    padding: 0px ${a(20)};
    align-self: center;
    margin: 0 auto;
    max-width: ${a(1320)};
`;export{d as A,U as B,Q as C,O as D,w as E,A as F,l as G,e as H,G as I,T as J,F as O,B as P,x as R,C as S,v as V,y as W,P as a,D as b,u as c,b as d,q as e,h as f,g,S as h,R as i,$ as j,t as k,o as l,c as m,W as n,p as o,V as p,z as q,a as r,n as s,I as t,m as u,r as v,H as w,i as x,k as y,f as z};
//# sourceMappingURL=config.dcd057e4.js.map
