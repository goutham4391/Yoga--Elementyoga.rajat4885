function n(t){var e=typeof t;return t!=null&&(e=="object"||e=="function")}var c=n;export{c as i};
//# sourceMappingURL=isObject.c70885d8.js.map
