<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Not Found (404)</title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="https://static.vhx.tv/error-pages/css/normalize.min.css">
        <link rel="stylesheet" href="https://static.vhx.tv/error-pages/css/main.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300">

        <script>
          getCookie = function(name) {
            var r = document.cookie.match("\\b" + name + "=([^;]*)\\b");
            return r ? r[1] : null;
          };
          var isGdprDisabled = (getCookie('gcp') !== "0") &&
            (window.location.href.indexOf('no_cookies=1') === -1);
          var madeForKidsEnabled = !!false;

          if (isGdprDisabled && !madeForKidsEnabled) {
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-19540423-6', 'auto');
            ga('require', 'displayfeatures');
            ga('send', 'pageview');
          }
        </script>
    </head>
    <body>
        <header>
            <h1>Not Found</h1>
        </header>

        <section>
            <p>Sorry! This page could not be found. Perhaps an old or mis-linked page?</p>
            <p>
              Would you like to go <a href='javascript:history.go(-1);' title='Go back'>back</a> or <a href='/' title='Go to homepage'>home</a>?
            </p>
        </section>
    </body>
</html>
